﻿using App.Model.Data;
using Microsoft.EntityFrameworkCore;

namespace App.Model
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions options) : base(options)
        {
            
        }

        public DbSet<Cards> Cards { get; set; }
        public DbSet<Users> Users { get; set; }
    }
}