﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App.Model.RequestModel.Users
{
    public class UpdateUserRequestModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public char Gender { get; set; }
        public DateTime DOB { get; set; }
        public int CardsId { get; set; }
    }
}
