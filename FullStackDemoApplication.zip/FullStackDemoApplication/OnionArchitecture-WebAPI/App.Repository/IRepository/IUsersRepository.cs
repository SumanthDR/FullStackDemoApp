﻿using App.Model.Data;
using App.Model.RequestModel;
using App.Model.RequestModel.Users;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App.Repository.IRepository
{
    public interface IUsersRepository
    {
        /// <summary>
        /// AddUsers
        /// </summary>
        /// <param name="addUsersRequestModel"></param>
        /// <returns>Users</returns>
        Task<Users> AddUserAsync(AddUsersRequestModel addUsersRequestModel);
        /// <summary>
        /// GetListOfUsers
        /// </summary>
        /// <returns>List of Users</returns>
        Task<List<UsersListResponseModel>> GetListOfUsersAsync();
        /// <summary>
        /// Get User By Id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<Users> GetUserByIdAsync(int id);
        /// <summary>
        /// Delete User by Id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<bool> DeleteUserByIdAsync(int id);
        /// <summary>
        /// Update User Details
        /// </summary>
        /// <param name="updateUserRequestModel"></param>
        /// <returns></returns>
        Task<Users> UpdateUserDetailsAsync(UpdateUserRequestModel updateUserRequestModel);
    }
}
