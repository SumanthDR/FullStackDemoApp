﻿using App.Model.RequestModel;
using App.Model.RequestModel.Cards;
using App.Model.RequestModel.Users;
using App.Service.IService;
using App.Service.Service;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace App.Web.Controllers.Users
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly IUsersService _IusersService;

        public UsersController(IUsersService IusersService)
        {
            _IusersService = IusersService;
        }

        [HttpPost("AddUser")]
        public async Task<IActionResult> AddUser(AddUsersRequestModel addUsersRequestModel)
        {
            var result = await _IusersService.AddUserAsync(addUsersRequestModel);
            return Ok(result);
        }

        [HttpGet("GetListOfUsers")]
        public async Task<IActionResult> GetListOfUsers()
        {
            var result = await _IusersService.GetListOfUsersAsync();
            return Ok(result);
        }

        [HttpGet("GetUserById")]
        public async Task<IActionResult> GetUserByIdAsync(int id)
        {
            var result = await _IusersService.GetUserByIdAsync(id);
            return Ok(result);
        }

        [HttpPut("DeleteUserById")]
        public async Task<IActionResult> DeleteUserByIdAsync(int id)
        {
            var result = await _IusersService.DeleteUserByIdAsync(id);
            return Ok(result);
        }

        [HttpPut("UpdateUserDetails")]
        public async Task<IActionResult> UpdateUserDetailsAsync(UpdateUserRequestModel updateUserRequestModel)
        {
            var result = await _IusersService.UpdateUserDetailsAsync(updateUserRequestModel);
            return Ok(result);
        }
    }
}
